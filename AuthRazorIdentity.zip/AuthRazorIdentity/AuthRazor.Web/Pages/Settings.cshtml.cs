using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AuthRazor.Web.Pages
{
    [Authorize(Roles = "User")]
    public class SettingsModel : PageModel
    {
        public ActionResult OnGet()
        {
            if (!ModelState.IsValid)
            {
                return RedirectToPage("~/Areas/Identity/Pages/Account/Login");
            }
            return Page();
        }
    }
}
