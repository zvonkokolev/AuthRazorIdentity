using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AuthRazor.Web.Pages
{
    [Authorize(Roles = "Admin")]
    public class AdministratorSettingsModel : PageModel
    {
        public ActionResult OnGet()
        {
            if (!ModelState.IsValid)
            {
                return RedirectToPage("Login");
            }
            return Page();
        }
    }
}
