using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AuthRazor.Web.Areas.Identity.Pages
{
    //[AllowAnonymous]
    [Authorize(Roles = "User")]
    public class SettingsModel : PageModel
    {
        public ActionResult OnGet()
        {
            if (!ModelState.IsValid)
            {
                return RedirectToPage("Login");
            }
            return Page();
        }
    }
}
