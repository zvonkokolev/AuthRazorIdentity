﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace AuthRazor.Persistence.Migrations
{
    public partial class Own_Migration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "AuthUsers",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    UserRole = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AuthUsers", x => x.Id);
                });

            migrationBuilder.InsertData(
                table: "AuthUsers",
                columns: new[] { "Id", "Email", "Password", "UserRole" },
                values: new object[] { 1, "admin@htl.at", "TkqfVN50MoGP3ZhOszPLAUSHeWo+354OJDM0aLSkkKE=2ac0e28fd6b611a05b9a980f581e748b", "Administrator" });

            migrationBuilder.InsertData(
                table: "AuthUsers",
                columns: new[] { "Id", "Email", "Password", "UserRole" },
                values: new object[] { 2, "user@htl.at", "xa6ZC0grtLXNuJHONuWUYCwUnRCZeqmNiwRFkmFzaAw=a3f817c10b90928cda26712fcdb08bda", "User" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AuthUsers");
        }
    }
}
